<?php
namespace backend\controllers;

use common\models\main\CargoModel;
use yii\web\Controller;

class MainController extends Controller {

    public function actionIndex(){
        $model = new CargoModel();

        $model->from = date("Y-m-d");
        $model->to = date("Y-m-d");
        $model->validate();
        echo "<pre>";
        print_r($model->getErrors());

//        return $this->render('index');
    }
}