<?php foreach($items as $id => $item):?>
    <option value="<?= $id?>"><?= $item?></option>
<?php endforeach;?>
