<?php
namespace frontend\models\search;

class TransportSearch
{
    public $from;
    public $to;

}