<?php
namespace frontend\components\telegram;

class Lang{

    public static function getList(){
        return [
            'uz' => 'Узбекча',
            'oz' => 'O\'zbekcha',
            'ru' => 'Русский',
        ];
    }
}