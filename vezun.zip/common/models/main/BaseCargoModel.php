<?php
namespace common\models\main;

use common\models\main\interfaces\CargoInterface;
use yii\base\Model;

class BaseCargoModel extends Model{

    public $model;
    /* map info */
    public $country_id;
    public $region_id;
    public $city_id;
    /*  map info */

    /* date info*/
    public $from;
    public $to;
    /* date info*/

    /* user info*/
    public $name;
    public $phone;
    public $bot_user_id;
    /* user info*/

    /* cargo info*/
    public $transport_type_id;
    /* cargo info*/


    public function rules(){

    }

    public function save($validate = true){
        if($validate){
            if(!$this->validate()){
                return false;
            }
        }

        $transaction = \Yii::$app->db->beginTransaction();

        $this->innerSave();

        if($this->model->save()){
            $transaction->commit();
            return true;
        }else{
            $transaction->rollBack();
            return false;
        }
    }

    public function innerSave(){


    }
    public function dateValidate(){

        $reg_date =  "/\d{4}-\d{2}-\d{2}/";
        if(!preg_match($reg_date, $this->from)){
            $this->addError('from', "Введите дату");
            return;
        }

        if(!preg_match($reg_date, $this->to)){
            $this->addError('to', "Введите дату");
            return;
        }


        $from = strtotime($this->from);
        $to = strtotime($this->to);
        if($from > $to){
            $this->addError('from', "Знечение не должно быть больше");
            $this->addError('to', "Знечение не должно быть меньше");
        }
    }



    public function getForeignItem($class, $key){
        if($this->model->isNewRecord){
            $item = $class::findOne($this->model->$key);
        }else{
            $item = new $class;
        }

        return $item;
    }


    public function setForeignItem($foreign_item){
        $function = "get".ucfirst($foreign_item['name']);
        $item = $this->$function($foreign_item['class'], $foreign_item['key']);

        $item->setAttributes($this->attributes);
        $item->save(false);

        $this->model->{$foreign_item['key']} = $item->id;
    }

    public static function listForeignItems(){

    }

}