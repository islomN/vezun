<?php
return [
    'components' => [
        'db' => [
            'dsn' => 'mysql:host=172.29.0.2;dbname=test_vezun',
            'username' => 'root',
            'password' => '123',
            'charset' => 'utf8',
        ],
    ],
];
